(()=>{"use strict";var e,r={642:(e,r,n)=>{var t=n(294),o=n(788),a=n(745);const l=()=>t.createElement("button",null,"Showing off"),i=o.ZP.div`
    * {
    margin: 0;
    padding: 0;
    }
    color: HotPink;
    background: black;
    width: 400px;
    height: 450px;
    padding: 0px;
    margin: 0px;
`;document.body.style.margin="0";const d=document.createElement("div");document.body.appendChild(d),(0,a.s)(d).render(t.createElement((()=>t.createElement(i,null,t.createElement("h1",null,"Options Page"),t.createElement(l,null))),null))}},n={};function t(e){var o=n[e];if(void 0!==o)return o.exports;var a=n[e]={exports:{}};return r[e](a,a.exports,t),a.exports}t.m=r,e=[],t.O=(r,n,o,a)=>{if(!n){var l=1/0;for(c=0;c<e.length;c++){for(var[n,o,a]=e[c],i=!0,d=0;d<n.length;d++)(!1&a||l>=a)&&Object.keys(t.O).every((e=>t.O[e](n[d])))?n.splice(d--,1):(i=!1,a<l&&(l=a));if(i){e.splice(c--,1);var p=o();void 0!==p&&(r=p)}}return r}a=a||0;for(var c=e.length;c>0&&e[c-1][2]>a;c--)e[c]=e[c-1];e[c]=[n,o,a]},t.n=e=>{var r=e&&e.__esModule?()=>e.default:()=>e;return t.d(r,{a:r}),r},t.d=(e,r)=>{for(var n in r)t.o(r,n)&&!t.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:r[n]})},t.o=(e,r)=>Object.prototype.hasOwnProperty.call(e,r),(()=>{var e={798:0};t.O.j=r=>0===e[r];var r=(r,n)=>{var o,a,[l,i,d]=n,p=0;if(l.some((r=>0!==e[r]))){for(o in i)t.o(i,o)&&(t.m[o]=i[o]);if(d)var c=d(t)}for(r&&r(n);p<l.length;p++)a=l[p],t.o(e,a)&&e[a]&&e[a][0](),e[a]=0;return t.O(c)},n=self.webpackChunkapp=self.webpackChunkapp||[];n.forEach(r.bind(null,0)),n.push=r.bind(null,n.push.bind(n))})(),t.nc=void 0;var o=t.O(void 0,[875],(()=>t(642)));o=t.O(o)})();