(()=>{"use strict";var e,t={645:(e,t,n)=>{var l=n(294),i=n(788),o=n(745);const r=i.ZP.h1`
    width: 100%;
    display: block;
    font-size: 24px;
    text-align: center;
`,a=({title:e})=>l.createElement(r,null,e),c={ADJ:"yellow",ADP:"teal",ADV:"pink",AUX:"grey",CCONJ:"grey",DET:"beige",INTJ:"red",NOUN:"blue",NUM:"coral",PART:"white",PRON:"orange",PROPN:"darkturquoise",PUNCT:"white",SCONJ:"darkgrey",SYM:"hotpink",VERB:"green",X:"white"},s=i.ZP.div`
    display: inline-block;
    background: ${e=>c[e.pos]};
    border: 1px solid grey;
    display: inline-block;
    border-radius: 18px;
    margin: 3px 3px;
    padding: 6px 12px;
    &:hover{
        opacity: .7;
    }
`,d=i.ZP.span`
    font-size: 16px;
`,m=i.ZP.span`
    padding-left:12px;
    font-size: 16px;
`,p=({word:e,handleBubbleClick:t})=>l.createElement(s,{pos:e[1],onClick:n=>{n.preventDefault(),n.stopPropagation(),t(e[0])}},l.createElement(d,null,e[0]),l.createElement(m,null,e[2])),u={ADJ:"yellow",ADP:"teal",ADV:"pink",AUX:"grey",CCONJ:"grey",DET:"beige",INTJ:"red",NOUN:"blue",NUM:"coral",PART:"white",PRON:"orange",PROPN:"darkturquoise",PUNCT:"white",SCONJ:"darkgrey",SYM:"hotpink",VERB:"green",X:"white"},h=i.ZP.div`
    background: ${e=>u[e.pos]};
    border-radius: 18px;
    margin: 3px 3px;
    padding: 6px 12px;
    display: flex;
    flex-direction: column;
    width: 100%;
`,g=i.ZP.span`
    font-size: 16px;
`,x=i.ZP.span`
    padding-left:12px;
    font-size: 16px;
`,f=i.ZP.div`
    background: white;
    margin-bottom: 8px;
    border-radius: 0 0 8px 8px;
    padding: 0px 8px;
`,v=({word:e,comments:t})=>l.createElement(h,{onClick:e=>{e.stopPropagation()},pos:e[1]},l.createElement("div",null,l.createElement(g,null,e[0]),l.createElement(x,null,e[2])),l.createElement(f,null,t.map(((e,t)=>l.createElement("p",{key:t},e))))),y=i.ZP.div`
    display: flex;
    justify-content: center;
    align-items: center;
    flex-flow: row wrap;
`,w=({words:e,detailWord:t,handleBubbleClick:n,onClick:i})=>{const o=e.map(((e,i)=>e[0]!==(null==t?void 0:t.word)?l.createElement(p,{key:i,word:e,handleBubbleClick:n}):l.createElement(v,{key:i,word:e,comments:null==t?void 0:t.comments})));return l.createElement(y,{onClick:i},o)},E=i.ZP.div`
    display: flex;
    flex-direction: column;
    min-height: 250px;
    max-height: 4250px;
`,k=i.ZP.div`
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 36px;
    color: darkgrey;
`,b=({commentData:e})=>{const[t,n]=(0,l.useState)(null),[i,o]=(0,l.useState)("");return(0,l.useEffect)((()=>{e&&o(null==e?void 0:e.words)}),[e]),l.createElement(E,null,i?l.createElement(w,{onClick:()=>n(null),words:i.slice(0,20),detailWord:t,handleBubbleClick:t=>{const l=e.comments.filter(((e,n)=>e.toLocaleLowerCase().includes(t.toLowerCase()))).slice(0,3).map((e=>e.slice(0,150)+"..."));n({word:t,comments:l})}}):l.createElement(k,null,"Loading"))};var P=n(648);const C=i.ZP.div`
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: end;
    width: 350px;
    height: 180px;
  
`,S=i.ZP.div`
    width: ${e=>e.width}px;
    height: ${e=>e.height}px;
    background: ${({totalBins:e,position:t})=>`rgb(${255*t/e},0,${255*(e-t)/e})`};
`,O=({sentiments:e,handleGraphClick:t})=>l.createElement(C,null,(()=>{if(!e)return;const n=e.map((e=>e.length));let i=Math.max(...n);console.log("array of totals",n);let o=e.length;const r=e.map(((n,r)=>((n,i,o,r)=>{const a=i.length/r*150;return l.createElement(S,{height:a,position:n,totalBins:o,key:n,width:300/e.length,onClick:()=>t(n,i.x0,i.x1)})})(r,n,o,i)));return r})());var N=n(554);const Z=i.ZP.div`
    display: flex;
    flex-direction: column;
    max-height: 250px;
    padding: 20px ;
    overflow-y: auto;
    overflow-x: hidden;
`,D=i.ZP.div`
    display: flex;
    flex-direction: row;
    width: 400px;
    justify-content: start;
    align-items: center;
    margin: 6px 0px;
`,A=i.ZP.div`
    font-size: 18px;
    color: darkgrey;
`,I=i.ZP.div`
    margin-left: 12px;
`,J=({comments:e,setShowSentimentComments:t})=>l.createElement(Z,null,(e=e.slice(0,3)).map(((e,n)=>l.createElement(D,{key:n,onClick:()=>t(!1)},l.createElement(A,null,e[1]),l.createElement(I,null,e[0]))))),R=i.ZP.div`
    display: flex;
    flex-direction: column;
    align-items:center;
    justify-content: center;
    height: 180px;
    
    border: 1px solid grey;
    margin: 15px;
    
`,U=({sentiments:e,comments:t,setShowSentimentComments:n,showSentimentComments:i})=>{const[o,r]=(0,l.useState)(null),[a,c]=(0,l.useState)(null);return(0,l.useEffect)((()=>{if(!e)return;let t=((e,t)=>N.Ly_().domain([-1,1]).thresholds(20)(e))(e.filter((e=>0!==e)));r(t)}),[e]),l.createElement(l.Fragment,null,i&&a&&l.createElement(J,{comments:a,setShowSentimentComments:n}),l.createElement(R,null,l.createElement(O,{sentiments:o,handleGraphClick:(l,i,o)=>{const r=[],a=[];e.map(((e,t)=>{e<o&&e>i&&r.push([t,e])})),r.map((e=>{a.push([t[e[0]],e[1]])})),n(!0),c(a)}}),l.createElement("div",null,"Sentiment analysis")))};var j=function(e,t,n,l){return new(n||(n=Promise))((function(i,o){function r(e){try{c(l.next(e))}catch(e){o(e)}}function a(e){try{c(l.throw(e))}catch(e){o(e)}}function c(e){var t;e.done?i(e.value):(t=e.value,t instanceof n?t:new n((function(e){e(t)}))).then(r,a)}c((l=l.apply(e,t||[])).next())}))};const z=i.ZP.div`
    html {
    margin: 0;
    padding: 0;
    }
    color: black;
    background: white;
    flex-direction: column;
    display: flex;
    width: 450px;
    padding: 0px;
    margin: 0px;
`,B=i.ZP.div`
    text-align: center;
    font-size: 24px;
    padding: 0px 18px 18px;
`;document.body.style.margin="0";const T=document.createElement("div");document.body.appendChild(T),(0,o.s)(T).render(l.createElement((()=>{const[e,t]=(0,l.useState)(null),[n,i]=(0,l.useState)(!0),[o,r]=(0,l.useState)(null),[c,s]=(0,l.useState)(!1);return(0,l.useEffect)((()=>{j(void 0,void 0,void 0,(function*(){let e;chrome.tabs.query({currentWindow:!0,active:!0},(function(n){const l=new URL(n[0].url),o=new URLSearchParams(l.search);e=o.get("v"),e?t(e):i(!1)}))}))}),[]),(0,l.useEffect)((()=>{e&&(e=>{j(void 0,void 0,void 0,(function*(){try{if(localStorage.getItem("videoId")!==e){const{data:t,status:n}=yield P.Z.get("https://sbk957ltol.execute-api.us-east-1.amazonaws.com/test/getanalysis",{params:{videoid:e,maxcomments:250}});r(t),localStorage.setItem("videoId",e),localStorage.setItem("data",JSON.stringify(t))}else{let e=JSON.parse(localStorage.getItem("data"));r(e)}}catch(e){console.log(e)}}))})(e)}),[e]),n?l.createElement(z,null,l.createElement(a,{title:`Insightor: ${e}`}),!c&&l.createElement(b,{commentData:o}),l.createElement(U,{sentiments:null==o?void 0:o.sentiments,comments:null==o?void 0:o.comments,setShowSentimentComments:s,showSentimentComments:c})):l.createElement(z,null,l.createElement(a,{title:"Insightor: no video"}),l.createElement(B,null,"Navigate to a youtube video then relaunch the extension to get comment insights"))}),null))}},n={};function l(e){var i=n[e];if(void 0!==i)return i.exports;var o=n[e]={exports:{}};return t[e](o,o.exports,l),o.exports}l.m=t,e=[],l.O=(t,n,i,o)=>{if(!n){var r=1/0;for(d=0;d<e.length;d++){for(var[n,i,o]=e[d],a=!0,c=0;c<n.length;c++)(!1&o||r>=o)&&Object.keys(l.O).every((e=>l.O[e](n[c])))?n.splice(c--,1):(a=!1,o<r&&(r=o));if(a){e.splice(d--,1);var s=i();void 0!==s&&(t=s)}}return t}o=o||0;for(var d=e.length;d>0&&e[d-1][2]>o;d--)e[d]=e[d-1];e[d]=[n,i,o]},l.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return l.d(t,{a:t}),t},l.d=(e,t)=>{for(var n in t)l.o(t,n)&&!l.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},l.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),(()=>{var e={42:0};l.O.j=t=>0===e[t];var t=(t,n)=>{var i,o,[r,a,c]=n,s=0;if(r.some((t=>0!==e[t]))){for(i in a)l.o(a,i)&&(l.m[i]=a[i]);if(c)var d=c(l)}for(t&&t(n);s<r.length;s++)o=r[s],l.o(e,o)&&e[o]&&e[o][0](),e[o]=0;return l.O(d)},n=self.webpackChunkapp=self.webpackChunkapp||[];n.forEach(t.bind(null,0)),n.push=t.bind(null,n.push.bind(n))})(),l.nc=void 0;var i=l.O(void 0,[875,196],(()=>l(645)));i=l.O(i)})();