STOP_WORDS = set(
    """
a abo aby ako ale až

daniž dokulaž

gaž

jolic

pak pótom

teke togodla
""".split()
)
